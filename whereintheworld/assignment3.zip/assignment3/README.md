comp20-clo
ASSIGNMENT 3
===============

Written by Cecily Lo. 
Last Modified on 11/22/2014.

The GET /redline.json API is functioning properly. The POST /sendLocation, GET/locations.json, and the index are not functioning.

I spent approximately 15 hours on this assignment. 