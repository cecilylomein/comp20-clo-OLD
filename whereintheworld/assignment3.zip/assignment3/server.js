// Express initialization
var express = require('express');
var bodyParser = require('body-parser');
var validator = require('validator');
var app = express();
var http = require('http');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));



// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost:3000/whereintheworld'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
  db = databaseConnection;
    });
if (db) {
  db.createCollection('students');
}





app.post('/sendLocation', function(request, response) {
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");
	var login = request.body.login;
  var lat = parseFloat(request.body.lat);
  var lng = parseFloat(request.body.lng);


  if (login==undefined||lat==undefined||lng==undefined) {
    response.send("incorrect input");
  } else {
    var d = new Date();
    var date = d.getDate();
    var toInsert = {
      "login": login,
      "lat": lat,
      "lng": lng,
      "created_at": date
    }

    db.collection('students', function(er, collection) {
      var id = collection.insert(toInsert, function(err, saved) {
        if (err) {
          response.send(500);
        } else {
          response.send(200);
        }
      });
    });


  }
  

});

app.get('/locations.json', function(request, response) {
  var login = request.body.login;
  console.log(login);
  if (login==undefined) {
    response.send("need correct login");
  } else {
     response.send(JSON.stringify(db.students.find()));
  }



});



app.get('/redline.json', function(request, response) {
  
  response.setHeader("Content-Type", "application/json");
  var data = '';
  http.get('http://developer.mbta.com/lib/rthr/red.json', function(apiresponse) {
    apiresponse.on('data', function(chunk) {
      data+=chunk;
    });
    apiresponse.on('end', function() {
      response.send(data);
    });
  }).on('error', function(error) {
    response.send(500);
  });

});


app.get('/', function(request, response) {
  response.set('Content-Type', 'text/html');
  var text = '';
  db.collection('students', function(er, collection) {
    collection.find().toArray(function( err, cursor) {
      if (!err) {
        text += "<!DOCTYPE HTML><html><head><title>Assignment 3</title></head><body><h1>Check-ins</h1>";
        for (var count = 0; count < cursor.length; count++ ) {
          text +=  "<p>Name: " + cursor[count].students.login + "  Lat: "
          + cursor[count].students.lat + " Lng: " + cursor[count].students.lng 
          + " Time: " + cursor[count].students.created_at + "</p>";
        }
        text += "</body></html>";
        response.send(text);
      } else {
        response.send('<!DOCTYPE HTML><html><head><title>Assignment 3</title></head><body><h1>Oops, I broke.</h1></body></html>');
      }
    });
  });



})




// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);
